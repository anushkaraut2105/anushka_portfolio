import { useEffect, useState } from "react"
import jodhaLogisticsProject from "../imports/Screenshot_2026-10-25_193143-2.png"
import scalingUpProject from "../imports/Screenshot_2026-10-25_193337-2.png"

type IconName = "arrow" | "code" | "database" | "external" | "layers" | "linkedin" | "mail" | "map" | "menu" | "phone" | "server" | "spark" | "x"

function Icon({ name, size = 20 }: { name: IconName size?: number }) {
  const paths: Record<IconName, React.ReactNode> = {
    arrow: (
      <>
        <path d="M5 12h14" />
        <path d="m13 6 6 6-6 6" />
      </>
    ),
    code: (
      <>
        <path d="m8 9-4 3 4 3" />
        <path d="m16 9 4 3-4 3" />
        <path d="m14 5-4 14" />
      </>
    ),
    database: (
      <>
        <ellipse cx="12" cy="5" rx="8" ry="3" />
        <path d="M4 5v6c0 1.7 3.6 3 8 3s8-1.3 8-3V5" />
        <path d="M4 11v6c0 1.7 3.6 3 8 3s8-1.3 8-3v-6" />
      </>
    ),
    external: (
      <>
        <path d="M15 4h5v5" />
        <path d="m10 14 10-10" />
        <path d="M18 13v6a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h6" />
      </>
    ),
    layers: (
      <>
        <path d="m12 2 9 5-9 5-9-5 9-5Z" />
        <path d="m3 12 9 5 9-5" />
        <path d="m3 17 9 5 9-5" />
      </>
    ),
    linkedin: (
      <>
        <path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-4 0v7h-4v-7a6 6 0 0 1 6-6Z" />
        <path d="M2 9h4v12H2z" />
        <path d="M4 6a2 2 0 1 0 0-4 2 2 0 0 0 0 4Z" />
      </>
    ),
    mail: (
      <>
        <rect x="3" y="5" width="18" height="14" rx="2" />
        <path d="m3 7 9 6 9-6" />
      </>
    ),
    map: (
      <>
        <path d="M20 10c0 5-8 12-8 12S4 15 4 10a8 8 0 1 1 16 0Z" />
        <circle cx="12" cy="10" r="2.5" />
      </>
    ),
    menu: (
      <>
        <path d="M4 7h16" />
        <path d="M4 12h16" />
        <path d="M4 17h16" />
      </>
    ),
    phone: (
      <path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 2 .7 2.8a2 2 0 0 1-.4 2.1L8.1 9.9a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.7 2Z" />
    ),
    server: (
      <>
        <rect x="3" y="4" width="18" height="6" rx="2" />
        <rect x="3" y="14" width="18" height="6" rx="2" />
        <path d="M7 7h.01M7 17h.01" />
      </>
    ),
    spark: (
      <path d="m12 3-1.5 4.5L6 9l4.5 1.5L12 15l1.5-4.5L18 9l-4.5-1.5L12 3ZM5 15l-.7 2.3L2 18l2.3.7L5 21l.7-2.3L8 18l-2.3-.7L5 15ZM19 14l-.7 1.3-1.3.7 1.3.7L19 18l.7-1.3 1.3-.7-1.3-.7L19 14Z" />
    ),
    x: (
      <>
        <path d="M18 6 6 18" />
        <path d="m6 6 12 12" />
      </>
    ),
  }
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      {paths[name]}
    </svg>
  )
}

const skills = [
  {
    title: "CMS & Development",
    icon: "layers" as IconName,
    items: [
      "WordPress",
      "Custom Themes",
      "Custom Post Types",
      "Elementor",
      "Hooks & Filters",
      "WPBakery",
      "WP-CLI",
    ],
  },
  {
    title: "E-Commerce",
    icon: "spark" as IconName,
    items: [
      "WooCommerce",
      "Checkout Customization",
      "Payment Gateways",
      "Product Management",
      "Inventory Management",
    ],
  },
  {
    title: "Backend & Database",
    icon: "database" as IconName,
    items: [
      "Core PHP",
      "MySQL",
      "ACF",
      "Custom Plugins",
      "Database Optimization",
      "REST APIs",
    ],
  },
  {
    title: "Frontend",
    icon: "code" as IconName,
    items: [
      "HTML5",
      "CSS3",
      "JavaScript",
      "jQuery",
      "Bootstrap",
      "Responsive Design",
      "Cross-Browser Compatibility",
    ],
  },
  {
    title: "Integrations",
    icon: "server" as IconName,
    items: [
      "Zoho CRM",
      "Tesseract OCR",
      "Webhooks",
      "JSON",
      "Third-Party APIs",
      "Postman",
    ],
  },
  {
    title: "Performance & Tools",
    icon: "spark" as IconName,
    items: [
      "Site Speed",
      "Security Hardening",
      "Git/GitHub",
      "WP Rocket",
      "Yoast SEO",
      "Wordfence",
      "cPanel",
    ],
  },
]

const projects = [
  {
    title: "Benity Care",
    category: "WordPress",
    label: "Healthcare",
    description:
      "A digital presence for an Australian registered NDIS provider offering disability assistance, personal care, accommodation support, and community participation.",
    url: "https://benitycare.com.au/",
    accent: "violet",
  },
  {
    title: "Zoho Helpdesk Sync",
    category: "Integrations",
    label: "API Integration",
    description:
      "A customized Zoho Desk setup synchronizing real-time user data with a WordPress CMS backend.",
    accent: "blue",
  },
  {
    title: "Dynamic Event Platform",
    category: "Integrations",
    label: "Data Automation",
    description:
      "An event listing platform using automated database scraping to compile localized event schedules.",
    url: "https://deluxebartendingservice.com/",
    accent: "pink",
  },
  {
    title: "Signature Smile Studio",
    category: "WordPress",
    label: "Healthcare",
    description:
      "A responsive, patient-focused website designed and developed for an Australian dental clinic.",
    url: "https://www.signaturesmilestudio.com.au/",
    accent: "violet",
  },
  {
    title: "Jodha Logistics",
    category: "WordPress",
    label: "Corporate",
    description:
      "A professional corporate web presence for an Australian international transport and logistics operation.",
    url: "https://jodhalogistics.com.au/",
    accent: "blue",
  },
  {
    title: "Scaling Up",
    category: "E-Commerce",
    label: "WooCommerce / AWS",
    description:
      "A maintained WooCommerce storefront supporting multi-region sales of books, digital downloads, and training materials.",
    url: "https://scalingup.com/",
    accent: "pink",
  },
]

const experience = [
  {
    role: "Full Stack Developer",
    company: "IP Websoft",
    date: "Jan 2026 — Present",
    points: [
      "Deliver responsive web projects that streamline online shopping experiences.",
      "Design user-centric WordPress solutions with dynamic content and optimized performance.",
      "Improve backend performance and UI/UX through focused troubleshooting and optimization.",
      "Support e-commerce development, deployment, and third-party API integration.",
    ],
  },
  {
    role: "Full Stack Developer",
    company: "Walstar Technologies Pvt. Ltd.",
    date: "Jan 2023 — Jan 2026",
    points: [
      "Developed PHP web applications and increased page load speed by 20%.",
      "Built custom WordPress themes and plugins with a focus on UX and SEO.",
      "Automated data scraping and integration workflows for dynamic website content.",
      "Delivered e-commerce, educational, and corporate websites end-to-end.",
      "Integrated Zoho CRM, OCR services, and other third-party REST APIs.",
    ],
  },
]

const education = [
  {
    school: "KIT's College of Engineering",
    degree: "B.Tech in Computer Science",
    date: "2019 — 2023",
  },
  {
    school: "S.M. Lohiya Jr. College",
    degree: "HSC in Science",
    date: "2017 — 2019",
  },
  { school: "Private English School", degree: "SSC", date: "2016 — 2017" },
]

export default function App() {
  const [menuOpen, setMenuOpen] = useState(false)
  const [activeSection, setActiveSection] = useState("home")
  const [projectFilter, setProjectFilter] = useState("All")

  useEffect(() => {
    const sections = document.querySelectorAll<HTMLElement>("main section[id]")
    const observer = new IntersectionObserver(
      (entries) =>
        entries.forEach(
          (entry) => entry.isIntersecting && setActiveSection(entry.target.id),
        ),
      { rootMargin: "-25% 0px -65% 0px" },
    )
    sections.forEach((section) => observer.observe(section))
    return () => observer.disconnect()
  }, [])

  const navItems = ["About", "Experience", "Skills", "Projects"]
  const filteredProjects =
    projectFilter === "All"
      ? projects
      : projects.filter((project) => project.category === projectFilter)

  const handleNav = () => setMenuOpen(false)

  return (
    <div className="app-shell">
      <header className="site-header">
        <a
          href="#home"
          className="brand"
          onClick={handleNav}
          aria-label="Anushka Raut, home"
        >
          <span>AR</span>
          <strong>Anushka Raut</strong>
        </a>
        <nav
          className={menuOpen ? "nav-links is-open" : "nav-links"}
          aria-label="Main navigation"
        >
          {navItems.map((item) => (
            <a
              key={item}
              href={`#${item.toLowerCase()}`}
              className={activeSection === item.toLowerCase() ? "active" : ""}
              onClick={handleNav}
            >
              {item}
            </a>
          ))}
          <a className="nav-contact" href="#contact" onClick={handleNav}>
            Let&apos;s talk <Icon name="arrow" size={16} />
          </a>
        </nav>
        <button
          className="menu-button"
          onClick={() => setMenuOpen(!menuOpen)}
          aria-label={menuOpen ? "Close menu" : "Open menu"}
          aria-expanded={menuOpen}
        >
          <Icon name={menuOpen ? "x" : "menu"} />
        </button>
      </header>

      <main>
        <section id="home" className="hero section-wrap">
          <div className="hero-glow glow-one" />
          <div className="hero-glow glow-two" />
          <div className="hero-content reveal">
            <p className="eyebrow">
              <span className="eyebrow-dot" /> Hello, I&apos;m Anushka Raut
            </p>
            <h1>
              I build thoughtful web experiences that <em>perform.</em>
            </h1>
            <p className="hero-copy">
              A Full Stack Developer and WordPress &amp; PHP specialist from
              Pune, creating fast, reliable digital products for real business
              needs.
            </p>
            <div className="hero-actions">
              <a href="#projects" className="button button-primary">
                Explore my work <Icon name="arrow" size={18} />
              </a>
              <a
                href="mailto:Anushkaraut2105@gmail.com"
                className="button button-secondary"
              >
                <Icon name="mail" size={18} /> Email me
              </a>
            </div>
            <div className="hero-proof">
              <div>
                <strong>3</strong>
                <span>
                  Years of
                  <br />
                  experience
                </span>
              </div>
              <div>
                <strong>20%</strong>
                <span>
                  Page speed
                  <br />
                  improvement
                </span>
              </div>
              <div>
                <strong>7</strong>
                <span>
                  Selected
                  <br />
                  projects
                </span>
              </div>
            </div>
          </div>
          <div className="hero-visual" aria-hidden="true">
            <div className="orbit orbit-one" />
            <div className="orbit orbit-two" />
            <div className="portrait-mark">
              <span className="mark-shine" />
              <span className="portrait-scan" />
              <img
                src="/anushka-raut-portrait.jpg"
                alt="Anushka Raut"
                className="absolute inset-0 h-full w-full object-cover object-top"
              />
              <small>
                <span>Based in Pune</span>WordPress &amp; PHP Specialist
              </small>
            </div>
            <div className="floating-card card-code">
              <Icon name="code" />
              <span>Clean code</span>
            </div>
            <div className="floating-card card-speed">
              <strong>+20%</strong>
              <span>Faster</span>
            </div>
            <div className="code-pill pill-one">&lt;WordPress /&gt;</div>
            <div className="code-pill pill-two">PHP · MySQL</div>
            <span className="portrait-spark spark-one">
              <Icon name="spark" size={18} />
            </span>
            <span className="portrait-spark spark-two">
              <Icon name="spark" size={14} />
            </span>
          </div>
        </section>

        <section id="about" className="about section-wrap">
          <div className="section-heading">
            <p className="section-kicker">About me</p>
            <h2>
              Development with purpose,
              <br />
              <span>built around people.</span>
            </h2>
          </div>
          <div className="about-grid">
            <div className="about-copy">
              <p className="lead">
                I create reliable digital experiences where thoughtful design
                meets robust development.
              </p>
              <p>
                With 3 years of full-stack experience, I specialize in
                cross-browser web development, e-commerce integration,
                performance optimization, and custom WordPress solutions.
              </p>
              <p>
                From building custom themes and plugins to connecting
                business-critical APIs, I focus on work that is responsive,
                maintainable, and tailored to real user needs.
              </p>
              <div className="language-row">
                <span>Languages</span>
                <strong>English</strong>
                <strong>German</strong>
                <strong>Hindi</strong>
              </div>
              <div className="about-actions">
                <a href="#experience" className="text-link">
                  See my experience <Icon name="arrow" size={17} />
                </a>
                <a href="#contact" className="text-link muted-link">
                  Start a conversation
                </a>
              </div>
            </div>
            <div className="focus-grid">
              <article
                style={{
                  backgroundImage:
                    "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='260' height='190' viewBox='0 0 260 190'%3E%3Cg opacity='.42' fill='none' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M72 40h136a16 16 0 0 1 16 16v91a16 16 0 0 1-16 16H72a16 16 0 0 1-16-16V56a16 16 0 0 1 16-16Z' fill='%23f4f0ff' stroke='%23cbbcf1' stroke-width='2'/%3E%3Cpath d='M57 68h166' stroke='%23cbbcf1' stroke-width='2'/%3E%3Ccircle cx='75' cy='54' r='4' fill='%23e96862'/%3E%3Ccircle cx='89' cy='54' r='4' fill='%23f2b45f'/%3E%3Ccircle cx='103' cy='54' r='4' fill='%23128c87'/%3E%3Crect x='75' y='85' width='54' height='57' rx='8' fill='%23ffffff' stroke='%23ded7e9'/%3E%3Cpath d='M89 102h25M89 113h18M89 124h22' stroke='%237652d6' stroke-width='4' opacity='.45'/%3E%3Crect x='143' y='85' width='62' height='22' rx='6' fill='%23e9e1ff'/%3E%3Crect x='143' y='117' width='28' height='25' rx='6' fill='%23d9f3f0'/%3E%3Crect x='177' y='117' width='28' height='25' rx='6' fill='%23ffe8e5'/%3E%3Ccircle cx='211' cy='145' r='28' fill='%237652d6' stroke='%23ffffff' stroke-width='5'/%3E%3Cpath d='m196 134 7 22 8-15 7 15 7-22' stroke='%23ffffff' stroke-width='4'/%3E%3Cpath d='M40 94 24 105l16 11M232 80l12-8 10 10' stroke='%237652d6' stroke-width='4' opacity='.5'/%3E%3C/g%3E%3C/svg%3E\"), linear-gradient(145deg, rgba(255,255,255,.97), rgba(244,240,255,.92))",
                  backgroundPosition: "right -10px bottom -8px, center",
                  backgroundRepeat: "no-repeat",
                  backgroundSize: "245px auto, cover",
                }}
              >
                <span>01</span>
                <Icon name="layers" />
                <h3>Custom WordPress</h3>
                <p>
                  Themes, plugins, CMS architecture, and content experiences
                  built to fit.
                </p>
              </article>
              <article
                style={{
                  backgroundImage:
                    "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='270' height='190' viewBox='0 0 270 190'%3E%3Cg opacity='.4' fill='none' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M78 43h137a15 15 0 0 1 15 15v91a15 15 0 0 1-15 15H78a15 15 0 0 1-15-15V58a15 15 0 0 1 15-15Z' fill='%23fff7f5' stroke='%23f0c5c1' stroke-width='2'/%3E%3Cpath d='M64 70h165' stroke='%23f0c5c1' stroke-width='2'/%3E%3Ccircle cx='82' cy='56' r='4' fill='%23e96862'/%3E%3Ccircle cx='96' cy='56' r='4' fill='%23f2b45f'/%3E%3Ccircle cx='110' cy='56' r='4' fill='%23128c87'/%3E%3Crect x='79' y='84' width='47' height='57' rx='8' fill='%23ffffff' stroke='%23efd8d5'/%3E%3Cpath d='M90 96h25l-3 20H93Z' fill='%23ffe1dd' stroke='%23e96862' stroke-width='2'/%3E%3Cpath d='M96 96a6 6 0 0 1 12 0' stroke='%23e96862' stroke-width='2'/%3E%3Cpath d='M91 128h22' stroke='%23e96862' stroke-width='4' opacity='.45'/%3E%3Crect x='138' y='84' width='71' height='21' rx='6' fill='%23ffe5e2'/%3E%3Cpath d='M150 94h31' stroke='%23e96862' stroke-width='3' opacity='.6'/%3E%3Crect x='138' y='115' width='71' height='26' rx='7' fill='%23ffffff' stroke='%23efd8d5'/%3E%3Cpath d='M150 124h22M150 132h34' stroke='%23c89f9b' stroke-width='3'/%3E%3Ccircle cx='216' cy='146' r='28' fill='%23e96862' stroke='%23ffffff' stroke-width='5'/%3E%3Cpath d='M203 137h4l3 12h14l4-9h-18M213 155h.1M222 155h.1' stroke='%23ffffff' stroke-width='3'/%3E%3Cpath d='m44 96 10-8 8 10M241 82l9 7-8 9' stroke='%23e96862' stroke-width='4' opacity='.5'/%3E%3C/g%3E%3C/svg%3E\"), linear-gradient(145deg, rgba(255,255,255,.97), rgba(255,244,242,.92))",
                  backgroundPosition: "right -14px bottom -8px, center",
                  backgroundRepeat: "no-repeat",
                  backgroundSize: "250px auto, cover",
                }}
              >
                <span>02</span>
                <Icon name="spark" />
                <h3>E-Commerce</h3>
                <p>
                  WooCommerce stores, checkout flows, payments, and inventory
                  workflows.
                </p>
              </article>
              <article
                style={{
                  backgroundImage:
                    "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='270' height='190' viewBox='0 0 270 190'%3E%3Cg opacity='.42' fill='none' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M84 39h126a16 16 0 0 1 16 16v94a16 16 0 0 1-16 16H84a16 16 0 0 1-16-16V55a16 16 0 0 1 16-16Z' fill='%23f1fbfa' stroke='%23b7dedb' stroke-width='2'/%3E%3Cpath d='M69 67h156' stroke='%23b7dedb' stroke-width='2'/%3E%3Ccircle cx='86' cy='53' r='4' fill='%23e96862'/%3E%3Ccircle cx='100' cy='53' r='4' fill='%23f2b45f'/%3E%3Ccircle cx='114' cy='53' r='4' fill='%23128c87'/%3E%3Crect x='86' y='82' width='43' height='28' rx='7' fill='%23ffffff' stroke='%239bceca'/%3E%3Cpath d='M96 92h23M96 100h16' stroke='%23128c87' stroke-width='3' opacity='.55'/%3E%3Crect x='166' y='82' width='43' height='28' rx='7' fill='%23ffffff' stroke='%239bceca'/%3E%3Cpath d='M176 92h23M176 100h15' stroke='%23128c87' stroke-width='3' opacity='.55'/%3E%3Cpath d='M130 96h35m-8-7 8 7-8 7' stroke='%23128c87' stroke-width='3'/%3E%3Ccircle cx='147' cy='133' r='22' fill='%23128c87' stroke='%23ffffff' stroke-width='5'/%3E%3Cpath d='M136 132h22M141 124l-7 8 7 8M153 124l7 8-7 8' stroke='%23ffffff' stroke-width='3'/%3E%3Cpath d='M108 111v13c0 5 4 9 9 9h7M187 111v13c0 5-4 9-9 9h-8' stroke='%23128c87' stroke-width='2' stroke-dasharray='4 5'/%3E%3Ccircle cx='108' cy='111' r='3' fill='%23128c87'/%3E%3Ccircle cx='187' cy='111' r='3' fill='%23128c87'/%3E%3Cpath d='m45 100 11-9 8 10M233 83l10 8-9 10' stroke='%23128c87' stroke-width='4' opacity='.48'/%3E%3Ccircle cx='49' cy='139' r='5' fill='%23d9f3f0' stroke='%23128c87'/%3E%3Cpath d='M54 139h20' stroke='%23128c87' stroke-width='2' stroke-dasharray='3 4'/%3E%3C/g%3E%3C/svg%3E\"), linear-gradient(145deg, rgba(255,255,255,.97), rgba(239,250,249,.92))",
                  backgroundPosition: "right -14px bottom -8px, center",
                  backgroundRepeat: "no-repeat",
                  backgroundSize: "250px auto, cover",
                }}
              >
                <span>03</span>
                <Icon name="server" />
                <h3>API Integration</h3>
                <p>
                  REST APIs, Zoho CRM, OCR services, webhooks, and data
                  automation.
                </p>
              </article>
              <article
                style={{
                  backgroundImage:
                    "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='270' height='190' viewBox='0 0 270 190'%3E%3Cg opacity='.42' fill='none' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M82 40h130a16 16 0 0 1 16 16v92a16 16 0 0 1-16 16H82a16 16 0 0 1-16-16V56a16 16 0 0 1 16-16Z' fill='%23f3f7ff' stroke='%23bed0f2' stroke-width='2'/%3E%3Cpath d='M67 68h160' stroke='%23bed0f2' stroke-width='2'/%3E%3Ccircle cx='84' cy='54' r='4' fill='%23e96862'/%3E%3Ccircle cx='98' cy='54' r='4' fill='%23f2b45f'/%3E%3Ccircle cx='112' cy='54' r='4' fill='%23128c87'/%3E%3Cpath d='M87 119a31 31 0 0 1 62 0' fill='%23ffffff' stroke='%239bb6e5' stroke-width='3'/%3E%3Cpath d='M118 119 137 94' stroke='%234b72c9' stroke-width='4'/%3E%3Ccircle cx='118' cy='119' r='6' fill='%234b72c9' stroke='%23ffffff' stroke-width='3'/%3E%3Cpath d='M93 111l-7-2M101 98l-5-6M118 91v-8M135 98l5-6M143 111l7-2' stroke='%234b72c9' stroke-width='3' opacity='.6'/%3E%3Crect x='89' y='133' width='58' height='12' rx='6' fill='%23dfe9fb'/%3E%3Cpath d='M91 139h43' stroke='%234b72c9' stroke-width='5'/%3E%3Cpath d='M179 83l22 8v17c0 15-9 25-22 31-13-6-22-16-22-31V91Z' fill='%234b72c9' stroke='%23ffffff' stroke-width='5'/%3E%3Cpath d='m168 108 8 8 15-18' stroke='%23ffffff' stroke-width='4'/%3E%3Cpath d='M166 149h41M172 157h29' stroke='%239bb6e5' stroke-width='3'/%3E%3Cpath d='m43 98 11-9 8 10M235 84l10 8-9 10' stroke='%234b72c9' stroke-width='4' opacity='.48'/%3E%3Ccircle cx='47' cy='139' r='5' fill='%23dfe9fb' stroke='%234b72c9'/%3E%3Cpath d='M52 139h20' stroke='%234b72c9' stroke-width='2' stroke-dasharray='3 4'/%3E%3C/g%3E%3C/svg%3E\"), linear-gradient(145deg, rgba(255,255,255,.97), rgba(241,246,255,.92))",
                  backgroundPosition: "right -14px bottom -8px, center",
                  backgroundRepeat: "no-repeat",
                  backgroundSize: "250px auto, cover",
                }}
              >
                <span>04</span>
                <Icon name="code" />
                <h3>Performance</h3>
                <p>
                  Speed optimization, secure delivery, and cross-browser
                  quality.
                </p>
              </article>
            </div>
          </div>
        </section>

        <section id="experience" className="experience">
          <div className="section-wrap experience-stage">
            <style>{`
              .experience-stage {
                position: relative;
                margin-top: -120px;
                margin-bottom: -120px;
                padding-top: 50px;
                padding-bottom: 50px;
                color: #f7f4ff;
                background:
                  radial-gradient(circle at 82% 12%, rgba(118, 82, 214, .2), transparent 28%),
                  radial-gradient(circle at 8% 88%, rgba(18, 140, 135, .12), transparent 24%),
                  #15121c;
                box-shadow: 0 0 0 100vmax #15121c;
                clip-path: inset(0 -100vmax);
                font-family: "Manrope", sans-serif;
              }

              .experience-stage .section-kicker {
                color: #67d8d1;
                font-size: 11px;
                font-weight: 800;
                letter-spacing: .18em;
                text-transform: uppercase;
              }

              .experience-stage .section-heading h2 {
                color: #f7f4ff;
                font-weight: 600;
                letter-spacing: -.055em;
              }

              .experience-stage .section-heading h2 span {
                color: #aa8bff;
                font-family: Georgia, serif;
                font-style: italic;
                font-weight: 400;
              }

              .experience-stage .split-heading > p {
                color: #aaa3b7;
                font-family: "DM Sans", sans-serif;
              }

              .experience-stage .timeline::before {
                background: rgba(170, 139, 255, .22);
              }

              .experience-stage .timeline-item {
                isolation: isolate;
                border-color: rgba(170, 139, 255, .16);
                transition: border-color .35s ease;
              }

              .experience-stage .timeline-item::before {
                content: "";
                position: absolute;
                z-index: -1;
                inset: 8px 0;
                border: 1px solid rgba(170, 139, 255, .18);
                border-radius: 18px;
                background: linear-gradient(100deg, rgba(118, 82, 214, .2), rgba(18, 140, 135, .08));
                box-shadow: 0 18px 50px rgba(0, 0, 0, .2);
                opacity: 0;
                transform: scaleX(.04);
                transform-origin: left center;
                transition: transform .5s cubic-bezier(.22, 1, .36, 1), opacity .25s ease;
              }

              .experience-stage .job-meta,
              .experience-stage .job-details {
                position: relative;
                z-index: 1;
                transition: transform .5s cubic-bezier(.22, 1, .36, 1);
              }

              .experience-stage .timeline-item:hover::before {
                opacity: 1;
                transform: scaleX(1);
              }

              .experience-stage .timeline-item:hover .job-meta,
              .experience-stage .timeline-item:hover .job-details {
                transform: translateX(14px);
              }

              .experience-stage .timeline-marker {
                border-color: #15121c;
                background: linear-gradient(135deg, #8f6af0, #5e38bd);
                box-shadow: 0 0 0 1px rgba(170, 139, 255, .32), 0 8px 24px rgba(94, 56, 189, .4);
              }

              .experience-stage .job-meta p {
                color: #67d8d1;
                letter-spacing: .12em;
              }

              .experience-stage .job-meta strong {
                color: #dcd6e8;
                font-weight: 600;
              }

              .experience-stage .job-details h3 {
                color: #f7f4ff;
                font-size: 25px;
                font-weight: 600;
              }

              .experience-stage .job-details li {
                color: #aaa3b7;
                font-family: "DM Sans", sans-serif;
              }

              .experience-stage .job-details li::before {
                background: #aa8bff;
                box-shadow: 0 0 10px rgba(170, 139, 255, .7);
              }

              @media (max-width: 760px) {
                .experience-stage {
                  margin-top: -85px;
                  margin-bottom: -85px;
                  padding-top: 50px;
                  padding-bottom: 50px;
                }

                .experience-stage .timeline-item:hover .job-meta,
                .experience-stage .timeline-item:hover .job-details {
                  transform: translateX(6px);
                }
              }

              @media (prefers-reduced-motion: reduce) {
                .experience-stage .timeline-item::before,
                .experience-stage .job-meta,
                .experience-stage .job-details {
                  transition: none;
                }
              }
            `}</style>
            <div className="section-heading split-heading">
              <div>
                <p className="section-kicker">Experience</p>
                <h2>
                  Where I&apos;ve made
                  <br />
                  <span>an impact.</span>
                </h2>
              </div>
              <p>
                Full-cycle web development across e-commerce, corporate,
                educational, and custom platform projects.
              </p>
            </div>
            <div className="timeline">
              {experience.map((job, index) => (
                <article className="timeline-item" key={job.company}>
                  <div className="timeline-marker">
                    <span>{String(index + 1).padStart(2, "0")}</span>
                  </div>
                  <div className="job-meta">
                    <p>{job.date}</p>
                    <strong>{job.company}</strong>
                  </div>
                  <div className="job-details">
                    <h3>{job.role}</h3>
                    <ul>
                      {job.points.map((point) => (
                        <li key={point}>{point}</li>
                      ))}
                    </ul>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section id="skills" className="skills section-wrap skills-showcase">
          <style>{`
            .skills-showcase {
              --skill-accent: var(--purple);
              isolation: isolate;
              padding-top: 50px;
              padding-bottom: 50px;
            }

            .skills-showcase::before {
              content: "";
              position: absolute;
              z-index: -1;
              top: 5%;
              left: 50%;
              width: 70%;
              height: 42%;
              border-radius: 50%;
              background: radial-gradient(circle, rgba(118, 82, 214, .1), transparent 68%);
              transform: translateX(-50%);
              filter: blur(24px);
              pointer-events: none;
            }

            .skills-showcase .skills-heading {
              display: grid;
              grid-template-columns: 1fr auto;
              align-items: end;
              gap: 48px;
              margin-bottom: 52px;
              text-align: left;
            }

            .skills-showcase .section-kicker {
              display: inline-flex;
              align-items: center;
              gap: 10px;
              color: var(--purple-dark);
              font-size: 11px;
              font-weight: 800;
              letter-spacing: .16em;
              text-transform: uppercase;
            }

            .skills-showcase .section-kicker::before {
              content: "";
              width: 28px;
              height: 2px;
              border-radius: 2px;
              background: linear-gradient(90deg, var(--coral), var(--purple));
            }

            .skills-showcase .section-heading h2 {
              max-width: 690px;
            }

            .skills-showcase .section-heading h2 span {
              color: var(--purple);
              font-family: Georgia, serif;
              font-style: italic;
              font-weight: 400;
            }

            .skills-showcase .skills-summary {
              min-width: 150px;
              padding: 18px 20px;
              border: 1px solid rgba(118, 82, 214, .16);
              border-radius: 18px;
              background: rgba(255, 255, 255, .72);
              box-shadow: 0 16px 40px rgba(55, 36, 83, .08);
              backdrop-filter: blur(12px);
            }

            .skills-showcase .skills-summary strong,
            .skills-showcase .skills-summary span {
              display: block;
            }

            .skills-showcase .skills-summary strong {
              color: var(--purple);
              font: 800 34px/1 "Manrope", sans-serif;
              letter-spacing: -.06em;
            }

            .skills-showcase .skills-summary span {
              margin-top: 7px;
              color: var(--muted);
              font-size: 10px;
              font-weight: 700;
              letter-spacing: .08em;
              text-transform: uppercase;
            }

            .skills-showcase .skills-grid {
              grid-template-columns: repeat(4, minmax(0, 1fr));
              grid-auto-flow: dense;
              gap: 16px;
            }

            .skills-showcase .skill-card {
              --card-accent: var(--purple);
              min-height: 245px;
              padding: 26px;
              border-color: color-mix(in srgb, var(--card-accent) 18%, white);
              border-radius: 22px;
              background:
                linear-gradient(145deg, rgba(255,255,255,.98), color-mix(in srgb, var(--card-accent) 6%, white));
              box-shadow: 0 14px 40px rgba(55, 36, 83, .07);
              transition: transform .35s cubic-bezier(.22, 1, .36, 1), box-shadow .35s ease, border-color .35s ease;
            }

            .skills-showcase .skill-card:nth-child(2),
            .skills-showcase .skill-card:nth-child(5) {
              --card-accent: var(--coral);
            }

            .skills-showcase .skill-card:nth-child(3),
            .skills-showcase .skill-card:nth-child(6) {
              --card-accent: var(--teal);
            }

            .skills-showcase .skill-card:nth-child(1),
            .skills-showcase .skill-card:nth-child(6) {
              grid-column: span 2;
            }

            .skills-showcase .skill-card::before {
              top: auto;
              right: 22px;
              bottom: 0;
              left: 22px;
              width: auto;
              height: 3px;
              border-radius: 3px 3px 0 0;
              background: linear-gradient(90deg, transparent, var(--card-accent), transparent);
              opacity: .7;
            }

            .skills-showcase .skill-card::after {
              content: attr(data-index);
              position: absolute;
              right: 18px;
              bottom: -18px;
              color: color-mix(in srgb, var(--card-accent) 9%, transparent);
              font: 800 104px/1 "Manrope", sans-serif;
              letter-spacing: -.1em;
              pointer-events: none;
            }

            .skills-showcase .skill-card:hover {
              transform: translateY(-8px);
              border-color: color-mix(in srgb, var(--card-accent) 34%, white);
              box-shadow: 0 24px 55px color-mix(in srgb, var(--card-accent) 14%, transparent);
            }

            .skills-showcase .skill-card-top {
              position: relative;
              z-index: 1;
              display: flex;
              align-items: center;
              justify-content: space-between;
            }

            .skills-showcase .skill-icon {
              color: var(--card-accent);
              background: color-mix(in srgb, var(--card-accent) 11%, white);
              box-shadow: inset 0 0 0 1px color-mix(in srgb, var(--card-accent) 13%, transparent);
            }

            .skills-showcase .skill-card-index {
              color: color-mix(in srgb, var(--card-accent) 68%, var(--muted));
              font: 700 10px "Manrope", sans-serif;
              letter-spacing: .12em;
            }

            .skills-showcase .skill-card h3 {
              position: relative;
              z-index: 1;
              margin: 24px 0 18px;
              color: var(--ink);
              font-size: 18px;
              letter-spacing: -.025em;
            }

            .skills-showcase .skill-tags {
              position: relative;
              z-index: 1;
            }

            .skills-showcase .skill-tags span {
              border: 1px solid color-mix(in srgb, var(--card-accent) 12%, transparent);
              color: #625b6d;
              background: rgba(255, 255, 255, .72);
              backdrop-filter: blur(5px);
              transition: color .2s ease, border-color .2s ease, background .2s ease;
            }

            .skills-showcase .skill-card:hover .skill-tags span {
              border-color: color-mix(in srgb, var(--card-accent) 23%, transparent);
              color: color-mix(in srgb, var(--card-accent) 64%, var(--ink));
              background: rgba(255, 255, 255, .92);
            }

            @media (max-width: 980px) {
              .skills-showcase .skills-grid {
                grid-template-columns: repeat(2, minmax(0, 1fr));
              }
            }

            @media (max-width: 760px) {
              .skills-showcase .skills-heading {
                grid-template-columns: 1fr;
                gap: 24px;
                margin-bottom: 36px;
              }

              .skills-showcase .skills-summary {
                display: flex;
                min-width: 0;
                align-items: center;
                gap: 12px;
                width: fit-content;
              }

              .skills-showcase .skills-summary span {
                margin-top: 0;
              }

              .skills-showcase .skills-grid {
                grid-template-columns: 1fr;
              }

              .skills-showcase .skill-card:nth-child(1),
              .skills-showcase .skill-card:nth-child(6) {
                grid-column: span 1;
              }
            }

            @media (prefers-reduced-motion: reduce) {
              .skills-showcase .skill-card,
              .skills-showcase .skill-tags span {
                transition: none;
              }
            }
          `}</style>
          <div className="section-heading skills-heading">
            <div>
              <p className="section-kicker">Technical toolkit</p>
              <h2>
                Tools I use to turn
                <br />
                <span>ideas into reality.</span>
              </h2>
            </div>
            <div className="skills-summary" aria-label="Six core skill groups">
              <strong>06</strong>
              <span>Core skill groups</span>
            </div>
          </div>
          <div className="skills-grid">
            {skills.map((group, index) => (
              <article
                className="skill-card"
                data-index={String(index + 1).padStart(2, "0")}
                key={group.title}
              >
                <div className="skill-card-top">
                  <div className="skill-icon">
                    <Icon name={group.icon} />
                  </div>
                  <span className="skill-card-index">
                    {String(index + 1).padStart(2, "0")}
                  </span>
                </div>
                <h3>{group.title}</h3>
                <div className="skill-tags">
                  {group.items.map((item) => (
                    <span key={item}>{item}</span>
                  ))}
                </div>
              </article>
            ))}
          </div>
        </section>

        <section id="projects" className="projects">
          <div className="section-wrap">
            <div className="section-heading split-heading project-heading">
              <div>
                <p className="section-kicker">Selected projects</p>
                <h2>
                  Work that solves
                  <br />
                  <span>real problems.</span>
                </h2>
              </div>
              <div className="filters" aria-label="Filter projects">
                {["All", "WordPress", "E-Commerce", "Integrations"].map(
                  (filter) => (
                    <button
                      key={filter}
                      className={projectFilter === filter ? "active" : ""}
                      onClick={() => setProjectFilter(filter)}
                    >
                      {filter}
                    </button>
                  ),
                )}
              </div>
            </div>
            <div className="projects-grid">
              {filteredProjects.map((project, index) => (
                <article
                  className={`project-card accent-${project.accent}`}
                  key={project.title}
                >
                  <div className="project-top">
                    <span className="project-number">
                      {String(index + 1).padStart(2, "0")}
                    </span>
                    <span className="project-label">{project.label}</span>
                  </div>
                  <div className="project-symbol" aria-hidden="true">
                    {project.title === "Benity Care" ? (
                      <img
                        src="/benity-care-project.jpg"
                        alt=""
                        className="h-full w-full object-cover"
                      />
                    ) : project.title === "Zoho Helpdesk Sync" ? (
                      <img
                        src="/zoho-project-logo.png"
                        alt=""
                        className="h-[140px] w-[360px] max-h-full max-w-full bg-white object-contain p-3"
                      />
                    ) : project.title === "Dynamic Event Platform" ? (
                      <img
                        src="/dynamic-event-project.jpg"
                        alt=""
                        className="h-[140px] w-[360px] max-h-full max-w-full object-cover"
                      />
                    ) : project.title === "Signature Smile Studio" ? (
                      <img
                        src="/signature-smile-project.jpg"
                        alt=""
                        className="h-[140px] w-[360px] max-h-full max-w-full object-cover"
                      />
                    ) : project.title === "Jodha Logistics" ? (
                      <img
                        src={jodhaLogisticsProject}
                        alt=""
                        className="h-[140px] w-[360px] max-h-full max-w-full object-cover"
                      />
                    ) : project.title === "Scaling Up" ? (
                      <img
                        src={scalingUpProject}
                        alt=""
                        className="h-[140px] w-[360px] max-h-full max-w-full object-cover"
                      />
                    ) : (
                      <span>{project.title.slice(0, 2).toUpperCase()}</span>
                    )}
                  </div>
                  <div className="project-content">
                    <h3>{project.title}</h3>
                    <p>{project.description}</p>
                    {project.url ? (
                      <a href={project.url} target="_blank" rel="noreferrer">
                        View live project <Icon name="external" size={16} />
                      </a>
                    ) : (
                      <span className="case-label">Integration project</span>
                    )}
                  </div>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section
          id="education"
          className="education section-wrap education-showcase"
        >
          <style>{`
            .education-showcase {
              position: relative;
              isolation: isolate;
              padding-top: 50px;
              padding-bottom: 50px;
              border: none;
            }

            .education-showcase::before {
              content: "";
              position: absolute;
              z-index: -2;
              inset: 0 -34px;
              border-radius: 34px;
              background:
                radial-gradient(circle at 8% 18%, rgba(118, 82, 214, .14), transparent 29%),
                radial-gradient(circle at 92% 82%, rgba(18, 140, 135, .1), transparent 27%),
                linear-gradient(135deg, rgba(247, 243, 255, .95), rgba(255, 255, 255, .92));
              box-shadow: inset 0 0 0 1px rgba(118, 82, 214, .08);
            }

            .education-showcase::after {
              content: "ED";
              position: absolute;
              z-index: -1;
              top: -38px;
              left: -6px;
              color: rgba(118, 82, 214, .045);
              font: 800 180px/1 "Manrope", sans-serif;
              letter-spacing: -.12em;
              pointer-events: none;
            }

            .education-showcase .education-intro {
              position: sticky;
              top: 120px;
            }

            .education-showcase .section-heading {
              margin-bottom: 28px;
            }

            .education-showcase .section-kicker {
              display: flex;
              align-items: center;
              gap: 10px;
            }

            .education-showcase .section-kicker::before {
              content: "";
              width: 30px;
              height: 2px;
              border-radius: 2px;
              background: linear-gradient(90deg, var(--coral), var(--purple));
            }

            .education-showcase .education-note {
              max-width: 330px;
              margin: 0;
              color: var(--muted);
              font-size: 14px;
              line-height: 1.75;
            }

            .education-showcase .education-count {
              display: inline-flex;
              margin-top: 26px;
              align-items: center;
              gap: 9px;
              color: var(--teal);
              font-size: 11px;
              font-weight: 800;
              letter-spacing: .08em;
              text-transform: uppercase;
            }

            .education-showcase .education-count::before {
              content: "03";
              display: grid;
              width: 38px;
              height: 38px;
              place-items: center;
              border-radius: 50%;
              color: var(--white);
              background: var(--teal);
              box-shadow: 0 8px 20px rgba(18, 140, 135, .22);
            }

            .education-showcase .education-list {
              position: relative;
              display: grid;
              gap: 12px;
            }

            .education-showcase .education-list::before {
              content: "";
              position: absolute;
              top: 38px;
              bottom: 38px;
              left: 26px;
              width: 1px;
              background: linear-gradient(var(--purple), var(--coral), var(--teal));
              opacity: .25;
            }

            .education-showcase .education-list article {
              position: relative;
              grid-template-columns: 54px 1fr auto;
              min-height: 118px;
              gap: 20px;
              padding: 24px 26px;
              overflow: hidden;
              border: 1px solid rgba(118, 82, 214, .1);
              border-radius: 20px;
              background: rgba(255, 255, 255, .82);
              box-shadow: 0 12px 34px rgba(55, 36, 83, .07);
              backdrop-filter: blur(10px);
              transition: transform .25s, box-shadow .25s, border-color .25s;
            }

            .education-showcase .education-list article::after {
              content: "";
              position: absolute;
              top: 0;
              right: 0;
              width: 5px;
              height: 100%;
              background: var(--purple);
              opacity: .72;
              transition: width .25s, opacity .25s;
            }

            .education-showcase .education-list article:nth-child(2)::after {
              background: var(--coral);
            }

            .education-showcase .education-list article:nth-child(3)::after {
              background: var(--teal);
            }

            .education-showcase .education-list article:hover {
              transform: translateX(-7px);
              border-color: rgba(118, 82, 214, .24);
              box-shadow: 0 20px 42px rgba(55, 36, 83, .12);
            }

            .education-showcase .education-list article:hover::after {
              width: 8px;
              opacity: 1;
            }

            .education-showcase .education-list article > span {
              z-index: 1;
              width: 40px;
              height: 40px;
              border: 0;
              border-radius: 50%;
              color: var(--white);
              background: var(--purple);
              box-shadow: 0 8px 18px rgba(118, 82, 214, .24);
              font-size: 10px;
            }

            .education-showcase .education-list article:nth-child(2) > span {
              background: var(--coral);
              box-shadow: 0 8px 18px rgba(233, 104, 98, .22);
            }

            .education-showcase .education-list article:nth-child(3) > span {
              background: var(--teal);
              box-shadow: 0 8px 18px rgba(18, 140, 135, .22);
            }

            .education-showcase .education-list h3 {
              margin-bottom: 8px;
              font-size: 18px;
              letter-spacing: -.025em;
            }

            .education-showcase .education-list time {
              padding: 8px 11px;
              border-radius: 999px;
              background: var(--purple-pale);
              white-space: nowrap;
            }

            @media (max-width: 980px) {
              .education-showcase .education-intro {
                position: static;
              }
            }

            @media (max-width: 760px) {
              .education-showcase::before {
                inset: 0 -16px;
                border-radius: 24px;
              }

              .education-showcase::after {
                font-size: 120px;
              }

              .education-showcase .education-list article {
                grid-template-columns: 46px 1fr;
                min-height: 0;
                padding: 21px 18px;
              }

              .education-showcase .education-list time {
                grid-column: 2;
                width: max-content;
              }
            }

            @media (prefers-reduced-motion: reduce) {
              .education-showcase .education-list article,
              .education-showcase .education-list article::after {
                transition: none;
              }
            }
          `}</style>
          <div className="education-intro">
            <div className="section-heading">
              <p className="section-kicker">Education</p>
              <h2>
                A foundation in
                <br />
                <span>computer science.</span>
              </h2>
            </div>
            <p className="education-note">
              A continuous academic journey from secondary education through a
              B.Tech in Computer Science.
            </p>
            <span className="education-count">Academic milestones</span>
          </div>
          <div className="education-list">
            {education.map((item, index) => (
              <article key={item.school}>
                <span>{String(index + 1).padStart(2, "0")}</span>
                <div>
                  <h3>{item.school}</h3>
                  <p>{item.degree}</p>
                </div>
                <time>{item.date}</time>
              </article>
            ))}
          </div>
        </section>

        <section
          id="contact"
          className="contact section-wrap"
          style={{ paddingTop: 50, paddingBottom: 50 }}
        >
          <div className="contact-card">
            <div className="contact-glow" />
            <p className="section-kicker light">Get in touch</p>
            <h2>
              Have a project in mind?
              <br />
              <span>Let&apos;s build it well.</span>
            </h2>
            <p>
              For project discussions and professional opportunities, reach out
              by email or connect with me on LinkedIn.
            </p>
            <div className="contact-actions">
              <a
                href="mailto:Anushkaraut2105@gmail.com"
                className="button button-light"
              >
                <Icon name="mail" /> Anushkaraut2105@gmail.com
              </a>
              <a
                href="https://linkedin.com/in/anushka-raut-87b657196"
                target="_blank"
                rel="noreferrer"
                className="button button-outline"
              >
                <Icon name="linkedin" /> LinkedIn
              </a>
            </div>
            <div className="contact-details">
              <a href="tel:+918080231219">
                <Icon name="phone" size={17} /> +91 8080231219
              </a>
              <span>
                <Icon name="map" size={17} /> Pune, Maharashtra
              </span>
            </div>
          </div>
        </section>
      </main>

      <footer className="site-footer" style={{ paddingBottom: 0 }}>
        <a href="#home" className="brand">
          <span>AR</span>
          <strong>Anushka Raut</strong>
        </a>
        <p>Full Stack Developer · WordPress &amp; PHP Specialist</p>
        <a href="#home">Back to top ↑</a>
      </footer>
    </div>
  )
}
